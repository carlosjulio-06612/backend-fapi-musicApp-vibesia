from .base import CRUDBase
from .crud_user import user
from .crud_playlist import playlist 
from .crud_artist import artist
from .crud_song import song